import './App.css';
import GithubSearch from './components/GithubSearch';

function App() {
  return (
    <div className="App">
      <GithubSearch />
    </div>
  );
}

export default App;
